def studMarkRes(studMark):
    if studMark is not None:
        response={
            "mark" : studMark.mark,
            "student" : str(studMark.student)
        }
        return response
    return "No record found"

def studGradeRes(studGrade):
    if studGrade is not None:
        response={
            "Name" : studGrade.name,
            "mark" : studGrade.mark,
        }
        return response
    return "No record found"