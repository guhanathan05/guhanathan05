from django.db import models

# Create your models here.

class StudentDetails(models.Model):
    name = models.CharField(max_length=55, null=False)
    roll_no = models.CharField(max_length=55, unique=True, null=False)
    dob = models.DateField(null=False)
    # marks = models.IntegerField(null=False)

    def __str__(self):
        return self.name

class StudentMark(models.Model):
    student = models.ForeignKey(to=StudentDetails, on_delete=models.CASCADE)
    mark = models.IntegerField(null=False)

    def __str__(self):
        return str(self.student)
