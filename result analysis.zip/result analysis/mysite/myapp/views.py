from django.http import JsonResponse
from django.shortcuts import render
from .models import *
from .serializer import *
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework import mixins, generics
from rest_framework.views import APIView
from .studentMarkResponse import *

# Create your views here.


class StudentDetails_ListCreateView(generics.ListCreateAPIView):
    queryset = StudentDetails.objects.all()
    serializer_class = StudentDetailSerializer

# class StudentMark_ListCreateView(generics.ListCreateAPIView):
#     queryset = StudentMark.objects.all()
#     serializer_class = StudentMarkSerializer


class StudentMark_ListCreateView(APIView):
    def get(self, request):
        rec = StudentMark.objects.all()
        serializers = StudentMarkSerializer(rec, many=True)
        return Response(serializers.data)
    def post(self, request):
        serializers_data = StudentMarkSerializer(data=request.data)

        if serializers_data.is_valid():
            print(serializers_data.data['student'])
            try:
                student = StudentDetails.objects.get(roll_no=serializers_data.data['student'])
            except Exception as e:
                return Response("id not found", status=status.HTTP_400_BAD_REQUEST)

            studentMark = StudentMark.objects.create(student=student, mark=serializers_data.data['mark'])
            return Response(studMarkRes(studMark=studentMark), status=status.HTTP_201_CREATED)
        return Response(serializers_data.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def grade(request):
    rec = StudentDetails.objects.all()
    no_of_student = len(rec)

    grade_A = StudentMark.objects.filter(mark__range=[91, 100])
    no_grade_a = len(grade_A)
    grade_B = StudentMark.objects.filter(mark__range=[81, 90])
    no_grade_b = len(grade_B)
    grade_C = StudentMark.objects.filter(mark__range=[71, 80])
    no_grade_c = len(grade_C)
    grade_D = StudentMark.objects.filter(mark__range=[61, 70])
    no_grade_d = len(grade_D)
    grade_E = StudentMark.objects.filter(mark__range=[55, 61])
    no_grade_e = len(grade_E)
    grade_F = StudentMark.objects.filter(mark__range=[0, 54])
    no_grade_f = len(grade_F)

    distinction = no_grade_a / no_of_student

    firstClass = (no_grade_b + no_grade_c) / no_of_student

    passClass = (no_of_student - no_grade_f) / no_of_student

    context = {
        "Total_No_Of_Student" : no_of_student,
        "Total_students_having_Grade-A" : no_grade_a,
        "Total_students_having_Grade-B": no_grade_b,
        "Total_students_having_Grade-C": no_grade_c,
        "Total_students_having_Grade-D": no_grade_d,
        "Total_students_having_Grade-E": no_grade_e,
        "Total_students_having_Grade-F": no_grade_f,
        "Distinction % ": distinction,
        "First Class %" : firstClass,
        "Pass Class %" : passClass

    }

    return Response(context)







