from django.contrib import admin
from .models import StudentDetails, StudentMark

# Register your models here.
admin.site.register(StudentDetails)
admin.site.register(StudentMark)