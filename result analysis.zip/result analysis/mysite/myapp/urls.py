from django.urls import path
from .views import *

urlpatterns = [
    path('student/', StudentDetails_ListCreateView.as_view()),
    path('student/add-mark', StudentMark_ListCreateView.as_view()),
    path('student/results', grade)

]