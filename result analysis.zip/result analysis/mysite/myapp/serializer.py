from .models import StudentDetails, StudentMark
from rest_framework import serializers

class StudentDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model= StudentDetails
        fields = '__all__'

class StudentMarkSerializer(serializers.Serializer):
    student = serializers.CharField()
    mark = serializers.IntegerField()


